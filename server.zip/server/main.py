import socket
import pickle
import tqdm
import copy
import os
import shutil
import zipfile

from time import sleep
from _thread import *
from sys import getsizeof

from models.Net import Net
from utils.options import args_parser

global costs

args = args_parser()
soc = socket.socket()

host = '192.168.0.103'
port = 10000
clients = list()
print("Socket is created.")

try:
    soc.bind((host, port))
    print("Socket is bound to an address & port number.")
except socket.error as e:
    print(str(e))

print("Listening for incoming connection ...")
soc.listen()

def updateLocalWeight(connection, model_path, ID):
    with open("{}.zip".format(model_path), "rb") as f:
        bytes_read = f.read()
        msg = pickle.dumps(bytes_read)
        connection.sendall(msg)

    print("Sent model to client")

    received_data = []
    while True:
        part = connection.recv(4092)
        received_data.append(part)
        try:
            bytes_data = b''.join(received_data)
            data = pickle.loads(bytes_data)
            break
        except Exception as e:
            # print(e)
            pass
    
    with open("models/client_{}/save/model.keras.zip".format(ID), "wb") as f:
        f.write(bytes_data)

    with zipfile.ZipFile("models/client_{}/save/model.keras.zip".format(ID), 'r', compression=zipfile.ZIP_DEFLATED) as zip_ref:
        for member in zip_ref.namelist():
            filename = os.path.basename(member)
            if not filename:
                continue
            source = zip_ref.open(member)
            target = open(os.path.join("models/client_{}/extract".format(ID), filename), "wb")
            with source, target:
                shutil.copyfileobj(source, target)

    print("Received updated model from client")
    costs.append(os.path.getsize("models/client_{}/save/model.keras.zip".format(ID)))
    return None

net = Net(args=args)
print('Waiting for {} clients...'.format(args.num_users))
while True:
    connection, address = soc.accept()
    clients.append({
        "connection": connection,
        "address": address
    })
    print('Connected to: ' + address[0] + ':' + str(address[1]))
    print('Thread Number ' + str(len(clients)))
    if(len(clients) >= args.num_users):
        print("Clients ready")
    else:
        continue

    sleep(3)
    all_costs = list()
    w_i = list()
    e_acc = list()
    e_loss = list()
    for i in range(args.epochs):
        costs = list()
        print("")
        print("Global epoch : {}/{}".format((i+1), args.epochs))
        ID = 0
        for client in clients:
            try:
                start_new_thread(updateLocalWeight, (client["connection"], net.model_path, ID))
                ID += 1
            except Exception as e:
                print("Error : {}".format(e))
                print("disconnected from " + str(client["address"][0]) + ':' + str(client["address"][1]))
                #clients.remove(client)

        client_weights = list()
        while True:
            if len(costs) == (args.num_users):
                round_cost = 0
                for n in range(len(costs)):
                    model_path = "models/client_{}/extract/model.keras".format(n)
                    model = net.loadModel(model_path)
                    # print(model)
                    weights = net.getModelWeight(model)
                    client_weights.append(weights)
                    round_cost += costs[n]

                all_costs.append(round_cost / 1000000)
                print("Calculating average weight...")
                average_weights = net.fedAvg(client_weights)

                print("Testing model...")
                net.saveModel()
                loss, accuracy = net.test()
                e_loss.append(loss)
                e_acc.append(accuracy)
                print("\nTesting Loss : {}".format(loss))
                print("Testing Accuracy : {:.3f}%".format(accuracy))
                break

    print("\nPruning : {}".format("Yes" if args.prune else "No"))
    print("Quantization : {}".format("Yes" if args.quantize else "No"))
    
    print("\nHistory : ")
    print("Loss : {}".format(e_loss))
    print("Accuracy (%) : {}".format(e_acc))
    print("Cost (MB) : ", all_costs)
    
    print("\nAccuracy on epoch {} : {:.3f}%".format(args.epochs, accuracy))
    avg_cost = sum(all_costs) / len(all_costs)
    print("Average cost : {:.3f} MB".format(avg_cost))
    print("Total cost : {:.3f} MB".format(sum(all_costs)))
    print("\nProcess Completed")
    for client in clients:
        msg = pickle.dumps("done")
        client["connection"].sendall(msg)
    break

soc.close()
print("Socket is closed.")

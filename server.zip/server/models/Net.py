from tensorflow import keras, lite, nn
import tensorflow_model_optimization as tfmot
from utils.encoder import NumpyArrayEncoder

from sys import getsizeof
import numpy as np
import json
import tempfile
import copy
import zipfile
import os

class Net():
    def __init__(self, args):
        self.args = args
        mnist = keras.datasets.mnist
        (self.train_images, self.train_labels), (self.test_images, self.test_labels) = mnist.load_data()

        self.train_images = self.train_images.reshape((self.train_images.shape[0], 28, 28, 1))
        self.test_images = self.test_images.reshape((self.test_images.shape[0], 28, 28, 1))

        init_model = keras.Sequential([
            keras.layers.InputLayer(input_shape=(28, 28, 1)),
            keras.layers.Conv2D(filters=12, kernel_size=(3, 3), activation='relu'),
            keras.layers.MaxPooling2D(pool_size=(2, 2)),
            keras.layers.Flatten(),
            keras.layers.Dense(10)
        ])
        
        print("\nInitializing weights, please wait...\n")
        if args.quantize:
            init_model, _ = self.train(init_model)
            self.model = tfmot.quantization.keras.quantize_model(init_model)
    
        if args.prune:
            num_images = self.train_images.shape[0] * (1 - self.args.validation_split)
            end_step = np.ceil(num_images / self.args.bs).astype(np.int32) * args.local_ep
            pruning_params = {
                'pruning_schedule': tfmot.sparsity.keras.PolynomialDecay(initial_sparsity=0.50,
                                                                        final_sparsity=0.80,
                                                                        begin_step=0,
                                                                        end_step=end_step)
            }

            self.model = tfmot.sparsity.keras.prune_low_magnitude(init_model, **pruning_params)

            callbacks = [
                tfmot.sparsity.keras.UpdatePruningStep(),
                tfmot.sparsity.keras.PruningSummaries(log_dir=tempfile.mkdtemp()),
            ]

            self.model, _ = self.train(self.model, callbacks)
            
        if not self.args.quantize and not self.args.prune:
            self.model = init_model
            # self.model, _ = self.train(self.model)
        
        if self.args.dump_weights:
            self.dumpWeights()
        
        self.model_path = "models/server/save/model.keras"
        self.saveModel()

        # print("File Size : {:.3f} MB".format(os.path.getsize(self.model_path) / 1000000 ))
        # print("Zipped File Size : {:.3f} MB\n".format(os.path.getsize("{}.zip".format(self.model_path)) / 1000000 ))
        # exit()
        
    def saveModel(self):
        if self.args.quantize:
            self.model = self.compile(self.model)
        
        self.model.save(self.model_path)
        with zipfile.ZipFile("{}.zip".format(self.model_path), 'w', compression=zipfile.ZIP_DEFLATED) as f:
            f.write(self.model_path)
        return None

    def loadModel(self, model_path):
        try:
            with tfmot.quantization.keras.quantize_scope(): 
                self.model = keras.models.load_model(model_path)
        except:
            try:
                with tfmot.sparsity.keras.prune_scope(): 
                    self.model = keras.models.load_model(model_path)
            except:
                self.model = keras.models.load_model(model_path)

        return self.model

    def compile(self, model):
        model.compile(optimizer='adam',
                loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                metrics=['accuracy'])
        return model

    def test(self):
        result, accuracy = self.model.evaluate(
            self.test_images,
            self.test_labels,
            verbose=self.args.verbose
        )
        return round(result, 3), round((accuracy * 100), 3)

    def train(self, model, callbacks=None):
        model = self.compile(model)
        history = model.fit(
                self.train_images,
                self.train_labels,
                epochs=self.args.local_ep,
                validation_split=self.args.validation_split,
                callbacks=callbacks,
                verbose=self.args.verbose
        )

        return model, history

    def getModelWeight(self, model):
        weights = list()
        for layer in model.layers:
            weights.append(layer.get_weights())
        return weights

    def fedAvg(self, client_weights):
        average_weight = list()
        for i in range(len(client_weights[0])):
            layer_weights = list()
            if len(client_weights) > 1:
                for w in client_weights:
                    try:
                        layer_weights.append(w[i].astype(np.float64))
                    except:
                        try:
                            w_ = np.array(w[i], dtype=object)
                            layer_weights.append(w_.astype(np.float64))
                        except:
                            layer_weights.append(w[i])
                try:
                    # print(layer_weights)
                    average_weight.append(keras.layers.Average()(layer_weights))
                    # print("calculated average weight of layer ", i)
                except:
                    average_weight.append(client_weights[0][i])
            else:
                average_weight.append(client_weights[0][i])
        
        for i in range(len(self.model.layers)):
            self.model.layers[i].set_weights(average_weight[i]) 
    
        return average_weight


    #################

    def dumpWeights(self):
        weights = list()
        for layer in self.model.layers:
            weight = layer.get_weights()
            weights.append(weight)

        if self.args.quantize and self.args.prune :
            filepath = "dumped_weights/quantization_and_pruning.json"
        if not self.args.quantize or not self.args.prune :
            filepath = "dumped_weights/{}.json".format("quantization" if self.args.quantize else "pruning")
        if not self.args.quantize and not self.args.prune :
            filepath = "dumped_weights/baseline.json"

        data = np.hstack(weights)
        if self.args.quantize:
            for i in range(len(data)):
                try:
                    data[i] = data[i].astype(float)
                except:
                    pass

        with open(filepath, 'w') as file_:
            json.dump(data, file_, cls=NumpyArrayEncoder)